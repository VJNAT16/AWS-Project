# mkdir /ws
# cd /ws
# pip3 install flask

# vi app.py
put code here

# flask run --host=0.0.0.0
